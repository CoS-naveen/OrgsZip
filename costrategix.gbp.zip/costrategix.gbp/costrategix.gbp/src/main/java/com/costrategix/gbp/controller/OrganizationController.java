package com.costrategix.gbp.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.costrategix.gbp.entity.Organizations;
import com.costrategix.gbp.repository.OrganizationRepo;

@RestController
public class OrganizationController {

	@Autowired
	private OrganizationRepo repo;
	
		@GetMapping("/orgs")
	    public List<String> getAllOrgss() {
	        List<Organizations> L = repo.findAll();
	        ArrayList<String> empty = new ArrayList<>();
	        for(Organizations org : L) {
	        	empty.add(org.getName());
	        }
	        return empty;
	    }

}
