package com.costrategix.gbp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.costrategix.gbp.entity.Organizations;


@Repository
public interface  OrganizationRepo extends JpaRepository<Organizations,Integer>{

}
